function AppController() {
    this.header = {
        height : 53  
    };
    this.footer = {
        height : 53  
    };
    this.controllers = {};
    this.init = function(){
        $.each(this.controllers, function(i,controller){
            controller.init();
        });
    };
    this.onInitialized = function() {
        
    };
    
    return this;   
}
app = new AppController();

function Controller() {
    return this;   
}
Controller.prototype = {
    url : '',
    suburls : '',
    isRoot : false,
    sel : '',
    $sel : null,
    testURL : function(lastevt, evt){
        console.log(evt.pathNames + ',' + this.isRoot + ':::' + (evt.pathNames[0] == ''));
        return (evt.pathNames[0] == this.url) || (this.isRoot && evt.pathNames[0] == '');
    },
    processURL : function(lastevt, evt){
        var _this = this;
        if(this.testURL(lastevt, evt)){
            $.each(app.controllers, function(i,controller){
                if(_this == controller) controller.show();
                else controller.hide();
            });
            return true;   
        }
        return false;
    },
    init : function() {
        this.$sel = $(this.sel);   
    },
    show : function(a) {
        if(this.$sel.is('visible'))return;
        $(window).on('resize', this, this._onResize);
        this.onShow(a);
        this.$sel.show();
        this.onShown(a);
        $(window).trigger('resize');
    },
    hide : function(a) {
        if(!this.$sel.is('visible'))return;   
        $(window).off('resize', this._onResize);
        this.onHide(a);
        this.$sel.hide();
        this.onHidden(a);
    },
    onShow : function(a){
    },
    onShown : function(a){
    },
    onHide : function(a){
    },
    onHidden : function(a){
    },
    onResize : function(evt){
    },
    
    
    _onResize : function(evt){
        evt.data.onResize(evt);   
    }
};

function SliderController() {
    Controller.prototype.constructor.call(this);
    return this;   
}
SliderController.prototype = $.extend(Object.create(Controller.prototype), {
    $slider : null,
    $sliderContents : null,
    hammer: null,
    sliderOption : {
        mode: 'horizontal',
        controls: false,
        pager: false,
        touchEnabled: false,
        infiniteLoop: false,
        startSlide: 0
    },
    processURL : function(lastevt, evt) {
        var ret = Controller.prototype.processURL.call(this, lastevt, evt);  
        if(!ret)return false;
        var i = evt.pathNames.length < 2 ? 0 : this.suburls.indexOf(evt.pathNames[1]);
        this.$slider.goToSlide(i);
        return true;
    },
    init : function() {
        var _this = this;
        Controller.prototype.init.call(this);
        this.$sliderContents = this.$sel.find('.sliderContent');
        this.sliderOption.onSlideBefore = function($slideElement, oldIndex, newIndex){
            _this.$sliderContents.eq(newIndex).scrollTop(1);
        };
        this.sliderOption.onSlideAfter = function($slideElement, oldIndex, newIndex){
            $.address.value('/' + _this.url + '/' + _this.suburls[newIndex]);
        };
        this.$slider = this.$sel.find('.slider').bxSlider(this.sliderOption);
    },
    onShow : function() {
        var _this = this;
        this.hammer = new Hammer(this.$sel.find('.sliderContainer').addBack('.sliderContainer')[0], {});
        this.hammer.on('swipeleft swiperight', function(evt){
            if(evt.type == 'swipeleft') _this.$slider.goToNextSlide();
            else _this.$slider.goToPrevSlide();
        });
        $(document).on('keydown', this, this._onKeyDown);
    },
    onHide : function() {
        this.hammer.off('swipeleft swiperight');
        $(document).off('keydown', this._onKeyDown);
    },
    onKeyDown : function(evt){
        
    },
    onResize : function(evt){
        var ww = $(window).width();
        var wh = $(window).height();
        console.log(this.$sel.length);
        this.$sliderContents.each(function(i){
            $(this).css({width:ww, height:wh - app.header.height, 'margin-top':app.header.height}); 
        });
        this.$sel.find('.bx-wrapper, .bx-viewport').each(function(i){
            $(this).css({height:wh}); 
        });
        this.$slider.redrawSlider();  
    },
    
    _onKeyDown : function(evt){
        evt.data.onKeyDown(evt);   
    }
});
function HomeController() {
    this.sel = '#about';
    this.url = 'about';
    this.isRoot = true;
    this.suburls = ['what-define-us', 'what-we-do', 'how-we-work'];
    return this;   
}
HomeController.prototype = $.extend(Object.create(SliderController.prototype), {});



$(document).ready(function(){
    bouncefix.add('sliderContent');
    
    app.controllers.home = new HomeController();
    app.init();
    
    var lastProcessedEvent = null;
    $.address.init(function(event) {
        var prevvalue = lastProcessedEvent ? lastProcessedEvent.value : "";
        console.log('address.init@' + prevvalue + ' > '+event.value);
        $('a').each(function() {
            var alink = $(this).attr('href') || "";
            if (alink.indexOf('#') == 0) {
                alink = '/' + alink.substring(1);
                $(this).toggleClass('selected', alink == event.value);
            }
        });
        $.each(app.controllers, function(name, controller) {
            if (controller.processURL(lastProcessedEvent, event)) {
                lastProcessedEvent = event;
                return false;
            }
        });

    }).bind('change', function(event) {
        var prevvalue = lastProcessedEvent ? lastProcessedEvent.value : "";
        console.log('address.change@' + prevvalue + ' > '+event.value);
        if (lastProcessedEvent && lastProcessedEvent.value == event.value) return;

        $('a').each(function() {
            var alink = $(this).attr('href') || "";
            if (alink.indexOf('#') == 0) {
                alink = '/' + alink.substring(1);
                $(this).toggleClass('selected', alink == event.value);
            }
        });
        var processed = false;
        $.each(app.controllers, function(name, controller) {
            if (controller.processURL(lastProcessedEvent, event)) {
                lastProcessedEvent = event;
                processed = true;
                return false;
            }
        });
    });
    
    
});